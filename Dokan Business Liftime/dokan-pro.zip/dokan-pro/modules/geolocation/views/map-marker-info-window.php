<div class="dokan-geo-map-info-window">
    <div class="dokan-clearfix">
        <div class="dokan-w9">
            <h3 class="info-title">
                <a href="{link}">{title}</a>
            </h3>
            <address>{address}</address>
        </div>

        <div class="dokan-w3">
            <img class="info-image" src="{image}" alt="{title}">
        </div>
    </div>
</div>

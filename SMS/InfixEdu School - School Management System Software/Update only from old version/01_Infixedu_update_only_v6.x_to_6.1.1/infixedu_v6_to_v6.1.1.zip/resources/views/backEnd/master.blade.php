
@include('backEnd.partials.header')

@yield('mainContent')

@include('backEnd.partials.footer')
@stack('css')
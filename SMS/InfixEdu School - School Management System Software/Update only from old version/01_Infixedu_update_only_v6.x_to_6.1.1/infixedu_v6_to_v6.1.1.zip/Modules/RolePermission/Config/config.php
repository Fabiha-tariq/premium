<?php

return [
    'name' => 'RolePermission'
];

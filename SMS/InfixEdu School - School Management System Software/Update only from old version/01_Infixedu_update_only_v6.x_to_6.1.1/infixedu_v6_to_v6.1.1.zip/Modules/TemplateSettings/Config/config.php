<?php

return [
    'name' => 'TemplateSettings'
];

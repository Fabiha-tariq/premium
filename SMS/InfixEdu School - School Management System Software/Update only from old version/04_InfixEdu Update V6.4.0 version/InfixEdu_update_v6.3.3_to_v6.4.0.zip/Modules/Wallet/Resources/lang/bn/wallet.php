<?php
return [
"diposit" => "Diposit",

"wallet_deposit" => "ওয়ালেট ডিপোজিট",

"pending_deposit" => "পেন্ডিং ডিপোজিট",

"approve_deposit" => "এপ্রুভ ডিপোজিট",

"reject_deposit" => "জমা প্রত্যাখ্যান করুন",

"extra" => "এক্সট্রা",

"wallet_details" => "ওয়ালেট বিবরণ",

"wallet_transaction" => "ওয়ালেট ট্রান্সলেশন",

"refund_request" => "Reकोषको Request",

"wallet_report" => "ওয়ালেট রিপোর্ট",

"reject_note" => "নোট প্রত্যাখ্যান করুন",

"approve_date" => "প্রমাণ তারিখ",

"reject_date" => "তারিখ প্রত্যাখ্যান করো",

"wallet_approve_request" => "ওয়ালেট এপ্রুভ রিকুয়েস্ট",

"wallet_reject_request" => "ওয়ালেট প্রত্যাখ্যান প্রত্যাখ্যান",

"approve_refund" => "প্রমাণিত রিফান্ড",

"view_bank_payment_reject_note" => "ভিউ ব্যাংক পেমেন্ট প্রত্যাখ্যান নোট",

"refund_file" => "ফাইল প্রত্যাহারের ফাইল",

"wallet_pending_request" => "ওয়ালেট পেন্ডিং রিকুয়েস্ট",

"view_file" => "ফাইল প্রদর্শন করো",

"view_feedback" => "ফিডব্যাক প্রদর্শন",

"add_balance" => "ব্যালেন্স যোগ করো",

"add_amount" => "যোগ করো",

"method" => "পদ্ধতি",

"Reject" => "প্রত্যাখ্যান করুন",

"Deposit" => "ডিপোজিট",

"Note" => "নোট",

"Amount" => "অ্যাকাউন্ট",

"Payment" => "পেমেন্ট",

"amount" => "অ্যাকাউন্ট",

"Approve" => "অ্যাপসিন",

"feedback" => " ফিডব্যাক ",

"reject" => " প্রত্যাখ্যান করুন ",

"payment" => "পেমেন্ট",

"Refund" => "রিফান্ড",

"refund" => "রিফান্ড",

"approve" => "অ্যাপসিন",

"note" => "নোট",

"deposit" => "ডিপোজিট",

"Method" => "পদ্ধতি",

"wallet" => "ওয়ালেট",

"apply_date" => "তারিখ প্রয়োগ করো",

"create_date" => "তারিখ তৈরি করো",

"my_wallet" => "আমার ওয়ালেট",

"view_note" => "নোট দেখাও",

"are_you_sure_to_approve" => "আপনি কি নিশ্চিত করতে পারছেন",

"are_you_sure_to_reject" => "আপনি কি প্রত্যাখ্যান করতে নিশ্চিত",

"issue_date" => "ইস্যু তারিখ",

];
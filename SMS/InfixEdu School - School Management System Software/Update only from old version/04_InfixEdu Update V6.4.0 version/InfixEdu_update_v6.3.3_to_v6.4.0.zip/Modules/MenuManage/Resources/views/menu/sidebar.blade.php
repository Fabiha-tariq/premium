<li>
    <a href="#subMenuPosition" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
        <span class="flaticon-reading"></span>
        @lang('menumanage::menuManage.menu')  
    </a>
    <ul class="collapse list-unstyled" id="subMenuPosition">

     
            <li>
                <a href="{{route('menumanage.index')}}"> @lang('menumanage::menuManage.manage_position')</a>
            </li>
       
        
    </ul>
</li>
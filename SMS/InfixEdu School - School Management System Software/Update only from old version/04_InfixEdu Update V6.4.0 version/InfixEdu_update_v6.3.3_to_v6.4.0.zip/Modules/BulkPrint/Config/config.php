<?php

return [
    'name' => 'BulkPrint'
];

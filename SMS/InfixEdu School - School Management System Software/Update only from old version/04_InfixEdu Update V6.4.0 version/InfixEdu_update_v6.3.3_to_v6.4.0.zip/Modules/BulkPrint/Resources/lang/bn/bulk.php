<?php
return [
    "generate" => "উত্পাদক",

    "showing_page" => "পৃষ্ঠা শেখাও",

    "Generate" => "উত্পাদক",

    "Prefix" => "প্রিফিক্স",

    "prefix" => "প্রিফিক্স",

    "grid_gap" => "গ্রিপ গ্যাপ",

    "select_certificate" => "সার্টিফিকেট বেছে নিন",

    "student_certificate" => "ছাত্র সার্টিফিকেট",

    "generate_id_card" => "আই-ডি কার্ড তৈরি করো",

    "bulk_print" => "বুল্ক মুদ্রণ",

    "bulk" => "বাল্ক",

    "per" => "Per",

    "part" => "পর্ব",

    "is_showing" => "চালিয়ে আছে",

    "format_standard_three_character" => "স্ট্যান্ডার্ড ফরম্যাট ৩ অক্ষর",

    "fees_invoice_settings" => "ফিস উদ্ভাবন সেটিংস",

    "fees_invoice_bulk_print" => "ফিস ইনভয়েস বাল্ক প্রিন্ট",

    "payroll_bulk_print" => "পে রোল বাল্ক প্রিন্ট",

    "staff_id_card" => "স্টাফ আইডি কার্ড",

    "bulkprint" => "বুল্ক মুদ্রণ",

    "invoice_settings" => "ইনভয়েস সেটিংস",

    "invoice_prefix_format_standard_three_character" => "ইনভয়েস প্রিফিক্স (বিন্যাস মান তিন অক্ষর)",

    "is_showing_signature" => "স্বাক্ষর স্বাক্ষর",

    "copy_for" => "কপি করো",

];
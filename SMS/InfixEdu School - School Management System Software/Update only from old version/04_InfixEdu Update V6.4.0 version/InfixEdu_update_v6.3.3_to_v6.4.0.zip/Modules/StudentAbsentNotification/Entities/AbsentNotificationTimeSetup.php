<?php

namespace Modules\StudentAbsentNotification\Entities;

use Illuminate\Database\Eloquent\Model;

class AbsentNotificationTimeSetup extends Model
{

    protected $fillable = [];
}

<?php

return [
    'name' => 'Fees'
];

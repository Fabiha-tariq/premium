<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckSection extends Model
{
    protected $table = 'sm_sections_new';
}

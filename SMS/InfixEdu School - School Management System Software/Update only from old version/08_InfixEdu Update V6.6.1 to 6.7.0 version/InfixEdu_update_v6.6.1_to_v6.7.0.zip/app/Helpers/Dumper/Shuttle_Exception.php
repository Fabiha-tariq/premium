<?php

namespace App\Helpers\Dumper;

class Shuttle_Exception extends \Exception
{

}

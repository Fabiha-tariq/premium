<?php

return [
    'name' => 'ExamPlan'
];

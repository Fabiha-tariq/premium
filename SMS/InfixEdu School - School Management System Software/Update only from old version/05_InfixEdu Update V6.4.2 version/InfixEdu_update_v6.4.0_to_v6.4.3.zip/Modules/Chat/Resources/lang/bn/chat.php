<?php
return [
"new_chat" => "নতুন চ্যাট",

"no_file_found" => "কোনো ফাইল পাওয়া যায়নি",

"your_requests" => "আপনার অনুসন্ধান",

"no_connection_request_found" => "সংযোগ অনুসন্ধান পাওয়া যায়নি",

"people_requests_you_to_connect" => "আপনি সংযুক্ত করতে আপনাকে অনুসন্ধান করুন",

"connection_connected_with_you" => "আপনার সাথে সংযোগ স্থাপন করা হয়েছে",

"no_connection_connected_request_found" => "সংযোগ অনুসন্ধান পাওয়া যায়নি",

"no_user_found_to_chat" => "কোনো ব্যবহারকারী পাওয়া যায়নি",

"chatting_method_settings" => "চ্যাটিং মেথট সেটিংস",

"generate_connections" => "সংযোগ তৈরি করো",

"generate_teacher_and_student_connection_for_old_class_&_subjects" => "পুরানো ক্লাস ও সাবজেক্টরের জন্য শিক্ষক এবং ছাত্র সংযোগ তৈরি করুন",

"chat_settings" => "ক্যাট সেটিংস",

"permission_settings" => "অনুমতি সংক্রান্ত বৈশিষ্ট্য",

"invitation_requirement" => "ইনভেশন রিকোয়ারমেন্ট",

"invitation_settings" => "ইনভাইটেশন সেটিংস",

"unblock_user" => "ব্যবহারকারী আনব্লক করো",

"block_user" => "BLock ব্যবহারকারী",

"no_user_found!" => "কোন ফাউন্ড ব্যবহারকারী নেই!",

"list" => "তালিকা",

"settings" => "সেটিংস",

"chat" => "চ্যাট",

"invitation" => "আমন্ত্রণ",

"required" => "আবশ্যক",

"generate" => "উত্পাদক",

"people" => "মানুষ",

"unblock" => "অবরোধ",

"start" => "আরম্ভ",

"can_teacher_chat_with_parents" => "পেরেন্টদের সঙ্গে শিক্ষক চ্যাট করতে পারেন",

"can_student_chat_with_admin_accounts" => "অ্যাডমিন, অ্যাকাউন্ট সহ স্টুডেন্ট চ্যাট",

"mb" => "মেগাবাইট",

"can_staff_or_teacher_ban_tudent" => "স্টাফ বা শিক্ষক বান স্টুডেন্ট",

"teacher_can_pinned_top_message" => "টিচার পিন টপ বার্তা",

"chat_box" => "চ্যাট বক্স",

"connected_with_you" => "আপনার সাথে সংযুক্ত",

"chat_list" => "চ্যাট তালিকা",

"blocked_user" => "ব্লক করা ব্যবহারকারী",

"can_make_group" => "গ্রুপ তৈরি করতে পারে",

"upload_file_limit" => "ফাইল লিমিট আপলোড করো",

"can_upload_file" => "ফাইল আপলোড করা যাবে",

"open_chat_system" => "ক্যাট সিস্টেম খোলো",

"admin_can_chat_without_invitation" => "এডমিন অনুমতি ছাড়া আলাপ করতে পারেন",

"List" => "তালিকা",

"Required" => "আবশ্যক",

"Generate" => "উত্পাদক",

"Settings" => "সেটিংস",

"Start" => "আরম্ভ",

"People" => "মানুষ",

];
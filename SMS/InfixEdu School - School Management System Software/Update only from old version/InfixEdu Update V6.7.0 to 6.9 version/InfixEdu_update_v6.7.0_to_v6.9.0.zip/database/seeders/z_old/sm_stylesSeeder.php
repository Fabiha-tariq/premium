<?php

namespace Database\Seeders;

    use App\SmStyle;
    use Illuminate\Database\Seeder;

    class sm_stylesSeeder extends Seeder
    {
        /**
         * Run the database seeds.
         *
         * @return void
         */
        public function run()
        {
//
//            $s = new SmStyle();
//            $s->style_name = 'Sky Blue';
//            $s->path_main_style = '1_blue_version/style.css';
//            $s->path_infix_style = '1_blue_version/infix.css';
//            $s->primary_color = 'var(--base_color)';
//            $s->primary_color2 = '#2c7be5';
//            $s->primary_color3 = '#2c7be5';
//            $s->title_color = '#222222';
//            $s->text_color = '#828bb2';
//            $s->white = '#ffffff';
//            $s->black = '#000000';
//            $s->sidebar_bg = '#e7ecff';
//            $s->save();


        }
    }

<li>
    <a  href="javascript:void(0)" class="has-arrow" aria-expanded="false">       
        <div class="nav_icon_small">
            <span class="flaticon-reading"></span>
        </div>
        <div class="nav_title">
            @lang('menumanage::menuManage.menu')  
        </div>
    </a>
    <ul class="list-unstyled" id="subMenuPosition">            
            <li>
                <a href="{{route('menumanage.index')}}"> @lang('menumanage::menuManage.manage_position')</a>
            </li>      
        
    </ul>
</li>
<?php

use Illuminate\Database\Migrations\Migration;

class InfixEdu650VersionUpdate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $queries = [
            "ALTER TABLE sm_currencies CHANGE academic_id academic_id INT(10) UNSIGNED NULL default NULL;",
        ];
        foreach ($queries as $query) {
            DB::statement("SET FOREIGN_KEY_CHECKS =0");
            DB::statement($query);
            DB::statement("SET FOREIGN_KEY_CHECKS =1");
        }


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

    }
}

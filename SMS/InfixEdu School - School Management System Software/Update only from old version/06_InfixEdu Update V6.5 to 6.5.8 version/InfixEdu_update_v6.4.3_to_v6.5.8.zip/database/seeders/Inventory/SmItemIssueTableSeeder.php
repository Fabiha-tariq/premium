<?php

namespace Database\Seeders\Inventory;

use Illuminate\Database\Seeder;

class SmItemIssueTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

<?php

namespace App\Traits;

use App\Models\SmCustomField;
use Modules\CustomField\Entities\CustomField;
use Modules\CustomField\Entities\CustomFieldResponse;

trait CustomFields
{
    public function storeFields($model, $fields, $form_name){


    }

    public function generateValidateRules($form_name): array
    {
        $fields = SmCustomField::where(['form_name' => $form_name])->get();
        $rules = [];
        if (count($fields)) {
            foreach ($fields as $field) {
                $field_rule = [];
                $field->required ? array_push($field_rule, 'required') : array_push($field_rule, 'nullable');
                // $field->min ? array_push($field_rule, 'min:' . $field->min) : '';
                // $field->max ? array_push($field_rule, 'max:' . $field->max) : '';

                $rules['customF.' . $field->label] = $field_rule;
            }
        }
        return $rules;
    }

}

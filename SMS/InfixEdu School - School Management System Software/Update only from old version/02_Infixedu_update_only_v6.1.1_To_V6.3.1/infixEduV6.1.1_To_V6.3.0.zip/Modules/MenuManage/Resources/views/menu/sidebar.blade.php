<li>
    <a href="{{route('menumanage.index')}}" id="menumanage.index">
        <span class="flaticon-reading"></span>
        @lang('lang.menu') @lang('lang.manage')
    </a>
</li>
<?php

return [
    'name' => 'StudentAbsentNotification'
];

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CopyGeneralSettingsFile extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $old_setting = base_path('general_settings.json');
        $new_setting = storage_path('app/chat/school_settings.json');
        if (file_exists($old_setting) && !file_exists($new_setting)) {
            if(copy($old_setting, $new_setting)){
                unlink($new_setting);
            }
        }

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
